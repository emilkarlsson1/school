package o1.city

import o1.Color


// TODO: define trait Demographic and turn this into a type hierarchy

final class Occupied(val label: Color)  {
  override def toString = s"occupied by the $label demographic"
}


object Vacant {
  override def toString = "vacant residence"
}

