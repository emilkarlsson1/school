package o1

object Takiaisohjelma2 extends App {


}