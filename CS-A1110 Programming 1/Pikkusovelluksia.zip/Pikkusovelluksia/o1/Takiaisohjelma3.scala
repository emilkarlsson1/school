package o1

object Takiaisohjelma3 extends App {


}