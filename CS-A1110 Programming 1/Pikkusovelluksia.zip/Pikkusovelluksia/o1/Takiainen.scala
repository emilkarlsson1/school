package o1

// Tämä luokka liittyy lukuun 3.1 ja on esitelty siellä.

class Takiainen {
  var sijainti = new Pos(0, 0)  // tuoreimman säilyttäjä
}

