package o1

object Takiaisohjelma4 extends App {


}