package o1.robots

import o1.CompassDir
import scala.util.Random

// TODO: implementation missing


