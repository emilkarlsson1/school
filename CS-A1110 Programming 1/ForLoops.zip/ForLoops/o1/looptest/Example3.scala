package o1.looptest

// This example is discussed in Chapter 5.6.

object Example3 extends App {

  for (number <- 1 to 1000) {
    println(number)
  }

}

