package o1.shapes

// This class is introduced in Chapter 7.3.

class Square(size: Double) extends Rectangle(size, size) {

}
