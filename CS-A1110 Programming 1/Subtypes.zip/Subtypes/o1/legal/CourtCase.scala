package o1.legal

// TODO: define class CourtCase

