package o1.legal


// TODO: define classes JuridicalPerson, HumanOrganization, GeographicalFeature, and Group.





















// TODO: uncomment the classes below

/*
class Nation(name: String, contact: NaturalPerson) extends HumanOrganization(name, contact) {
  def kind = "sovereign nation"

}

class Municipality(name: String, val nation: Nation, contact: NaturalPerson) extends HumanOrganization(name, contact) {
  def kind = "municipality of " + this.nation.name
}


class Corporation(val id: String, val seeksProfit: Boolean, name: String, contact: NaturalPerson) extends HumanOrganization(name, contact) {
  def kind = (if (this.seeksProfit) "for-" else "non-") + "profit corporation"
}
*/

