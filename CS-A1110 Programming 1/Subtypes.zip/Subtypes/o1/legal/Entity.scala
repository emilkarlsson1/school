package o1.legal


// TODO: define class Entity

