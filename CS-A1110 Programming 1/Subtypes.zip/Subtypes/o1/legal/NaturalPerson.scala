package o1.legal



// TODO: define classes NaturalPerson, FullCapacityPerson, and ReducedCapacityPerson


