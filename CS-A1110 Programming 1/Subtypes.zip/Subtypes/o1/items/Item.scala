package o1.items

// This class is introduced in Chapter 7.3.

class Item(val name: String) {

  override def toString = this.name

}