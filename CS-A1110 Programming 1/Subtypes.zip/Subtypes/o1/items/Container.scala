package o1.items

// TODO: complete as instructed in Chapter 7.3.

class Container {



  def addContent(newContent: Item): Unit = {

  }




}