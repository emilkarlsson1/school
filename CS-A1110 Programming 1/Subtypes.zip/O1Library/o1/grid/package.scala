package o1

////////////////// NOTE TO STUDENTS //////////////////////////
// For the purposes of our course, it's not necessary
// that you understand or even look at the code in this file.
//////////////////////////////////////////////////////////////

/** This package contains tools for working with grid-like two-dimensional structures.
  *
  * The contents of this package have aliases in the top-level package [[o1]], so they
  * are accessible to students simply via `import o1._`. */
package object grid {

  util.smclInit()

}
