package o1.rainfall

import scala.io.StdIn._

object RainfallApp extends App {

  // Enter your program here as instructed in Chapter 7.1.

}