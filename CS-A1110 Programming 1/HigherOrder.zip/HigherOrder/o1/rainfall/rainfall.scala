package o1

package object rainfall {

  // What goes here is described in Chapter 6.4.






}